//============================================================================
// Name        : Tests.cpp
// Author      : jackp
// Version     :
// Copyright   : "we publish everything we do"
// Description : Test of XAMP unpacking
//============================================================================
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <omp.h>
#include <pthread.h>

#include <iostream>
#ifdef _POSIX_MESSAGE_PASSING
#include <mqueue.h>
#endif

using namespace std;

enum {numberOfGroups=64, numberOfRows=1024, numberOfIndexes=18};
//enum {numberOfGroups=1, numberOfRows=1, numberOfIndexes=18};
enum {sizeOfInputGroups=9, sizeOfOutputGroups=8};
enum {sizeOfInputRow=numberOfGroups*sizeOfInputGroups, sizeofOutputRow=numberOfGroups*sizeOfOutputGroups};
enum {sizeofOutputBlock=numberOfRows*sizeofOutputRow, numberOfProcessBlocks=2};

uint16_t testData[sizeOfInputRow*numberOfRows*numberOfProcessBlocks];
uint32_t destData[sizeofOutputBlock*numberOfProcessBlocks];

unsigned numbThreads = 1;
unsigned scan = 0;
unsigned averageCount = 1;
unsigned iterationCount = 1;
unsigned* tnHisto;


long long int timeDiff(timespec* end, timespec* start) {
  long long int diff;
  diff =  (end->tv_sec - start->tv_sec) * 1000000000LL;
  diff += end->tv_nsec;
  diff -= start->tv_nsec;
  return diff;
}

void process() {
  uint32_t* inputp;
  uint32_t* outputp;
  unsigned a = averageCount;
  unsigned offset = 0;
  int j;
  int tid;
  unsigned counter;

  while (a--) {
      for (unsigned b=0; b<numberOfProcessBlocks; b++) {
        offset = 0;
        outputp = destData + sizeofOutputBlock*b;
        omp_set_num_threads(numbThreads);
#pragma omp parallel for default(none) shared(b, outputp, testData, tnHisto) \
                      private(j, inputp, offset, counter, tid)
        for (j=0; j<numberOfRows; j++) {
          tid = omp_get_thread_num();
          tnHisto[tid] += 1;
//          printf("Thread %d, row %d\n", tid, j);
          offset = j * (numberOfGroups + sizeOfOutputGroups);
          counter = 0;
          for (int g=0; g<numberOfGroups; g++) {
            for (int k=0; k<sizeOfOutputGroups; k++) {
              inputp = (uint32_t*)&testData[j*sizeOfInputRow + g*sizeOfInputGroups + k];
              outputp[offset + ((counter&0x1f)<<4)+counter>>5] = (*inputp >> (k<<1)) & 0x3ffff;
//              outputp[counter + offset] = (*inputp >> (k<<1)) & 0x3ffff;
              counter += 1;
            }
          }
        }
      }
  }
  return;
}

void printUsage(char* s) {
  printf( "Usage: %s [-s <max>] [-t <numberOfThreads>] [-a <2baveraged> | -i <iterations>\n", s);
}

int main(int argc, char **argv) {

  pthread_t     xtThread[16];
  timespec startTime, endTime;
  unsigned indexes[32];
  int maxThreads = omp_get_max_threads();
  printf("Maximum number of threads allowed is %d\n", maxThreads);
  tnHisto = (unsigned*) calloc(maxThreads+1, sizeof(unsigned));
  for (unsigned i=0; i<numberOfIndexes; i++) indexes[i] = i;
  unsigned j=0;

  extern char* optarg;
  int c;
  while( ( c = getopt( argc, argv, "s:t:a:i:-h" ) ) != EOF ) {

    switch(c) {
      case 's':
        scan = strtoul(optarg, NULL, 0);
        if (scan > maxThreads) scan = maxThreads;
        break;
      case 't':
        numbThreads = strtoul(optarg, NULL, 0);
        if (numbThreads > maxThreads) numbThreads = maxThreads;
        break;
      case 'a':
        averageCount = strtoul(optarg, NULL, 0);
        if (averageCount == 0) averageCount = 1;
        if (iterationCount>1) {
          cout << "You can average or iterate, but not both! Setting iteration count to 1" << endl;
          iterationCount = 1;
        }
        break;
      case 'i':
        iterationCount = strtoul(optarg, NULL, 0);
        if (iterationCount == 0) iterationCount = 1;
        if (averageCount>1) {
          cout << "You can average or iterate, but not both! Setting average count to 1" << endl;
          averageCount = 1;
        }
        break;
      case 'h':
        printUsage(argv[0]);
        return 0;
        break;
     default:
        printf("Error: Option could not be parsed!\n");
        printUsage(argv[0]);
        return -1;
        break;
    }
  }
  cout << "numbThreads(" << numbThreads <<  ") scan(" << scan << ") averageCount(" << averageCount << ") iterationCount(" << iterationCount << ")" << endl;
  for (j=0; j<numberOfRows; j++) {
    for (unsigned i=0; i<sizeOfInputRow; i+=sizeOfInputGroups) {
      //      cout << "Init loop index " << j << ":" << i << " " << j*sizeofOutputRow + i << endl;
      for (unsigned k=0; k<sizeOfInputGroups; k++) {
        testData[j*sizeofOutputRow + i+k]   = 0x1111 * (k*1);
      }
    }
  }

  if (scan) numbThreads = 1;
  do {
    long long unsigned accumulator = 0LL;
    unsigned i = iterationCount;

    while (i) {
      clock_gettime(CLOCK_REALTIME, &startTime);
      process();
      clock_gettime(CLOCK_REALTIME, &endTime);
      accumulator += timeDiff(&endTime, &startTime);
      i--;
      usleep(5000);
    }
    cout << "scan " << scan << " :: " << numbThreads << " threads, time in milliseconds " << accumulator / (1000000.0*averageCount*iterationCount) << endl;
    numbThreads = numbThreads == 0 ? 1 : numbThreads + 1;
  } while (scan && (numbThreads <= scan));

  printf("Thread histogram:\n");
  for (unsigned n=0; n<maxThreads; n++) {
    if (tnHisto[n]) printf("%u  %8u times\n", n, tnHisto[n]);
  }

//  for (int g=0; g<numberOfGroups; g++) {
//    for (int k=0; k<8; k++) {
//      cout << "  0x" << hex << destData[(g<<3)+k];
//    }
//    cout << endl;
//  }
  return 0;
}
