//============================================================================
// Name        : Tests.cpp
// Author      : jackp
// Version     :
// Copyright   : "we publish everything we do"
// Description : Test of XAMP unpacking
//============================================================================
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <pthread.h>

#include <iostream>
#ifdef _POSIX_MESSAGE_PASSING
#include <mqueue.h>
#endif

using namespace std;

enum {numberOfGroups=64, numberOfRows=1024, numberOfIndexes=18};
//enum {numberOfGroups=1, numberOfRows=1, numberOfIndexes=18};
enum {sizeOfInputGroups=9, sizeOfOutputGroups=8};
enum {sizeOfInputRow=numberOfGroups*sizeOfInputGroups, sizeofOutputRow=numberOfGroups*sizeOfOutputGroups};
enum {sizeofOutputBlock=numberOfRows*sizeofOutputRow, numberOfProcessBlocks=2};

uint16_t testData[sizeOfInputRow*numberOfRows*numberOfProcessBlocks];
uint32_t destData[sizeofOutputBlock*numberOfProcessBlocks];
unsigned numbThreads = 1;
unsigned scan = 0;
unsigned averageCount = 1;
unsigned iterationCount = 1;


long long int timeDiff(timespec* end, timespec* start) {
  long long int diff;
  diff =  (end->tv_sec - start->tv_sec) * 1000000000LL;
  diff += end->tv_nsec;
  diff -= start->tv_nsec;
  return diff;
}

void* wtMain(void* p) {
  unsigned index = *(unsigned*)p;
  uint32_t* inputp;
  uint32_t* outputp;
  unsigned a = averageCount;
  unsigned col;

  while (a--) {
    if (numbThreads) {
      for (unsigned b=0; b<numberOfProcessBlocks; b++) {
        col = 0;
        unsigned start = (numberOfRows * index) / numbThreads;
        outputp = destData + b*sizeofOutputBlock;
        for (unsigned j=start; j<start+numberOfRows/numbThreads; j++) {
          for (int g=0; g<numberOfGroups; g++) {
            for (int k=0; k<sizeOfOutputGroups; k++) {
              inputp = (uint32_t*)&testData[j*sizeOfInputRow + g*sizeOfInputGroups + k];
//              outputp[((col&0x1f)<<4)+col>>5] = (*inputp >> (k<<1)) & 0x3ffff;
              outputp[col] = (*inputp >> (k<<1)) & 0x3ffff;
              col += 1;
            }
          }
        }
      }
    }
  }
  pthread_exit(NULL);
  return NULL;
}

void printUsage(char* s) {
  printf( "Usage: %s [-s <max>] [-t <numberOfThreads>] [-a <2baveraged> | -i <iterations>\n", s);
}

int main(int argc, char **argv) {

  pthread_t     xtThread[16];
  timespec startTime, endTime;
  unsigned indexes[32];
  for (unsigned i=0; i<numberOfIndexes; i++) indexes[i] = i;
  unsigned j=0;

  extern char* optarg;
  int c;
  while( ( c = getopt( argc, argv, "s:t:a:i:-h" ) ) != EOF ) {

    switch(c) {
      case 's':
        scan = strtoul(optarg, NULL, 0);
        if (scan > numberOfIndexes) scan = numberOfIndexes;
        break;
      case 't':
        numbThreads = strtoul(optarg, NULL, 0);
        if (numbThreads > numberOfIndexes) numbThreads = numberOfIndexes;
        break;
      case 'a':
        averageCount = strtoul(optarg, NULL, 0);
        if (averageCount == 0) averageCount = 1;
        if (iterationCount>1) {
          cout << "You can average or iterate, but not both! Setting iteration count to 1" << endl;
          iterationCount = 1;
        }
        break;
      case 'i':
        iterationCount = strtoul(optarg, NULL, 0);
        if (iterationCount == 0) iterationCount = 1;
        if (averageCount>1) {
          cout << "You can average or iterate, but not both! Setting average count to 1" << endl;
          averageCount = 1;
        }
        break;
      case 'h':
        printUsage(argv[0]);
        return 0;
        break;
     default:
        printf("Error: Option could not be parsed!\n");
        printUsage(argv[0]);
        return -1;
        break;
    }
  }
  cout << "numbThreads(" << numbThreads <<  ") scan(" << scan << ") averageCount(" << averageCount << ") iterationCount(" << iterationCount << ")" << endl;
  for (j=0; j<numberOfRows; j++) {
    for (unsigned i=0; i<sizeOfInputRow*numberOfRows; i+=9) {
//      cout << "Init loop index " << j << ":" << i << " " << j*sizeofOutputRow + i << endl;
      testData[j*sizeofOutputRow + i]   = 0x1111;
      testData[j*sizeofOutputRow + i+1] = 0x2222;
      testData[j*sizeofOutputRow + i+2] = 0x3333;
      testData[j*sizeofOutputRow + i+3] = 0x4444;
      testData[j*sizeofOutputRow + i+4] = 0x5555;
      testData[j*sizeofOutputRow + i+5] = 0x6666;
      testData[j*sizeofOutputRow + i+6] = 0x7777;
      testData[j*sizeofOutputRow + i+7] = 0x8888;
      testData[j*sizeofOutputRow + i+8] = 0x9999;
    }
  }

  if (scan) numbThreads = 0;
  do {
    long long unsigned accumulator = 0LL;
    unsigned i = iterationCount;

    while (i) {
      clock_gettime(CLOCK_REALTIME, &startTime);
      for (j=0; j<numbThreads; j++) {
        if ( int r = pthread_create(xtThread+j,NULL,wtMain,indexes+j) ) {

          printf("Error creating WorkerThread thread %d\n", r);
          return(2);
          //    } else {
          //      printf("Created WorkerThread thread xtThread(0x%x) (%d)\n", (unsigned)xtThread[j], (int)xtThread[j]);
        }
      }
      for (j=0; j<numbThreads; j++) {
        pthread_join(xtThread[j], NULL);
      }
      clock_gettime(CLOCK_REALTIME, &endTime);
      accumulator += timeDiff(&endTime, &startTime);
      i--;
      usleep(5000);
    }
    cout << "scan " << scan << " :: " << numbThreads << " threads, time in milliseconds " << accumulator / (1000000LL * averageCount*iterationCount) << endl;
  } while (scan && (numbThreads++ < scan));

//  for (int g=0; g<numberOfGroups; g++) {
//    for (int k=0; k<8; k++) {
//      cout << "  0x" << hex << destData[(g<<3)+k];
//    }
//    cout << endl;
//  }
  return 0;
}
