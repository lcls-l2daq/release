#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

void mult(int m, float* a);
void print(int m, float* a);

int main(int argc, char *argv[])
{
   float *a;
   int i, m;

  printf("Please give m: ");
   scanf("%d",&m);
   printf("\n");

   if ( (a=(float *)malloc(m*sizeof(double))) == NULL )
      perror("memory allocation for a");

   printf("Initializing matrix A\n");
   for (i=0; i<m; i++) a[i] = i*1.0;

   print(m, a);
   printf("Executing mult function for m = %d\n",m);
   omp_set_num_threads(4);
   mult(m, a);
   print(m, a);

   free(a);
   return(0);
}

void mult(int m, float * a)
{
   int i ;
   int tid;

#pragma omp parallel for default(none) \
        shared(m,a) private(i, tid)
   for (i=0; i<m; i++)
   {
      a[i] *= 2.0;
      tid = omp_get_thread_num();
      printf("%d %d\n", tid, i);

   } /*-- End of omp parallel for --*/
}

void print(int m, float * a)
{
   int i;

   printf("Printing the A array ...\n");
   for (i=0; i<m; i++) {
      printf("% 10f", a[i]);
      if ((i&0x7)==0x7) printf("\n");
   }
   printf("\n");
}
